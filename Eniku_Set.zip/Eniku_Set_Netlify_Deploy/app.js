/**
 * Eniku Set (እንቁ ሴት) - Web Portal & ESP32 Vending Simulator JS Logic
 */

document.addEventListener('DOMContentLoaded', () => {
  // Mock Database in LocalStorage
  const DEFAULT_USER = {
    fullName: "Selamawit Tadesse",
    phone: "0911223344",
    pin: "1234",
    totalQuota: 30,
    remainingQuota: 30,
    usedCount: 0,
    subscriptionDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    expiryDate: new Date(Date.now() + 90*24*60*60*1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
    paymentMethod: "Telebirr",
    history: [
      {
        title: "3-Month Subscription Activated",
        detail: "150 ETB via Telebirr - Granted 30 Pads",
        time: "Just now",
        type: "1"
      }
    ]
  };

  // Initialize store if not present
  if (!localStorage.getItem('eniku_user')) {
    localStorage.setItem('eniku_user', JSON.stringify(DEFAULT_USER));
  }

  let currentUser = JSON.parse(localStorage.getItem('eniku_user'));

  // Additional pre-configured accounts for machine testing
  const REGISTERED_ACCOUNTS = {
    "1234": currentUser,
    "4321": { fullName: "Abeba Tesfaye", remainingQuota: 28, usedCount: 2, totalQuota: 30 },
    "9999": { fullName: "Makeda Wolde", remainingQuota: 15, usedCount: 15, totalQuota: 30 }
  };

  // UI Elements
  const registerForm = document.getElementById('registerForm');
  const optionTelebirr = document.getElementById('optionTelebirr');
  const optionCBE = document.getElementById('optionCBE');
  const telebirrFields = document.getElementById('telebirrFields');
  const cbeFields = document.getElementById('cbeFields');
  
  // Dashboard UI Elements
  const dashUserName = document.getElementById('dashUserName');
  const dashUserPhone = document.getElementById('dashUserPhone');
  const dashAvatar = document.getElementById('dashAvatar');
  const quotaText = document.getElementById('quotaText');
  const meterFill = document.getElementById('meterFill');
  const dashExpiry = document.getElementById('dashExpiry');
  const dashPinCode = document.getElementById('dashPinCode');
  const togglePinBtn = document.getElementById('togglePinBtn');
  const resetPinBtn = document.getElementById('resetPinBtn');
  const historyList = document.getElementById('historyList');

  // Simulator UI Elements
  const lcdLine1 = document.getElementById('lcdLine1');
  const lcdLine2 = document.getElementById('lcdLine2');
  const lcdLine3 = document.getElementById('lcdLine3');
  const lcdLine4 = document.getElementById('lcdLine4');
  const keyBtns = document.querySelectorAll('.key-btn');
  const motor1Ind = document.getElementById('motor1Ind');
  const motor2Ind = document.getElementById('motor2Ind');
  const motor3Ind = document.getElementById('motor3Ind');
  const chuteSlot = document.getElementById('chuteSlot');
  const dispensedItem = document.getElementById('dispensedItem');
  const dispensedItemName = document.getElementById('dispensedItemName');

  // Simulator State Machine
  // Step 1: Entry PIN
  // Step 2: Product Type Select
  // Step 3: Dispense & Balance Confirmation
  let simState = 1;
  let enteredPin = "";
  let activeSessionUser = null;
  let simTimer = null;

  // Render Initial Dashboard
  updateDashboardUI();

  // ==========================================
  // Payment Radio Toggle Handlers
  // ==========================================
  if (optionTelebirr && optionCBE) {
    optionTelebirr.addEventListener('click', () => {
      optionTelebirr.classList.add('active');
      optionCBE.classList.remove('active');
      telebirrFields.classList.remove('hidden');
      cbeFields.classList.add('hidden');
    });

    optionCBE.addEventListener('click', () => {
      optionCBE.classList.add('active');
      optionTelebirr.classList.remove('active');
      cbeFields.classList.remove('hidden');
      telebirrFields.classList.add('hidden');
    });
  }

  // ==========================================
  // Registration Form Submission Handler
  // ==========================================
  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();

      const fullName = document.getElementById('fullName').value.trim();
      const phoneNumber = document.getElementById('phoneNumber').value.trim();
      const pinCode = document.getElementById('pinCode').value.trim();
      const confirmPin = document.getElementById('confirmPin').value.trim();
      const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked').value;

      if (pinCode.length !== 4 || !/^\d{4}$/.test(pinCode)) {
        alert("Please enter a valid 4-digit numeric PIN code.");
        return;
      }

      if (pinCode !== confirmPin) {
        alert("PIN codes do not match. Please try again.");
        return;
      }

      // Simulate Payment Processing
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const originalText = submitBtn.innerHTML;
      submitBtn.disabled = true;
      submitBtn.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i> Processing ${paymentMethod} Payment (150 ETB)...`;

      setTimeout(() => {
        // Create updated user
        const initials = fullName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
        
        currentUser = {
          fullName: fullName,
          phone: phoneNumber,
          pin: pinCode,
          totalQuota: 30,
          remainingQuota: 30,
          usedCount: 0,
          subscriptionDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          expiryDate: new Date(Date.now() + 90*24*60*60*1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
          paymentMethod: paymentMethod,
          history: [
            {
              title: "3-Month Plan Activated",
              detail: `150 ETB paid via ${paymentMethod} - 30 Pads Quota`,
              time: "Just now",
              type: "1"
            }
          ]
        };

        // Save to LocalStorage & Accounts Map
        localStorage.setItem('eniku_user', JSON.stringify(currentUser));
        REGISTERED_ACCOUNTS[pinCode] = currentUser;

        updateDashboardUI();

        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;

        alert(`🎉 Registration & Payment Successful!\n\nWelcome ${fullName} to Eniku Set!\nYour 4-digit PIN is: ${pinCode}.\nYou now have 30 pads available for 3 months.`);

        // Scroll to Dashboard
        document.getElementById('dashboard').scrollIntoView({ behavior: 'smooth' });
      }, 1500);
    });
  }

  // ==========================================
  // Update Dashboard UI
  // ==========================================
  function updateDashboardUI() {
    if (!currentUser) return;

    dashUserName.textContent = currentUser.fullName;
    dashUserPhone.textContent = currentUser.phone;

    const initials = currentUser.fullName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
    dashAvatar.textContent = initials || "ES";

    quotaText.textContent = `${currentUser.remainingQuota} / ${currentUser.totalQuota} Pads Remaining`;
    
    const percentage = Math.max(0, Math.min(100, (currentUser.remainingQuota / currentUser.totalQuota) * 100));
    meterFill.style.width = `${percentage}%`;

    dashExpiry.textContent = currentUser.expiryDate;

    if (dashPinCode.dataset.visible === "true") {
      dashPinCode.textContent = currentUser.pin;
    } else {
      dashPinCode.textContent = "****";
    }

    // Render History
    historyList.innerHTML = currentUser.history.map(item => `
      <div class="history-item">
        <div class="history-icon type-${item.type || '1'}"><i class="fa-solid fa-box"></i></div>
        <div class="history-details">
          <strong>${item.title}</strong>
          <span>${item.detail}</span>
        </div>
        <span class="history-time">${item.time}</span>
      </div>
    `).join('');
  }

  // PIN Toggle Hide/Show
  if (togglePinBtn) {
    togglePinBtn.addEventListener('click', () => {
      const isVisible = dashPinCode.dataset.visible === "true";
      dashPinCode.dataset.visible = isVisible ? "false" : "true";
      dashPinCode.textContent = isVisible ? "****" : currentUser.pin;
      togglePinBtn.innerHTML = isVisible ? `<i class="fa-solid fa-eye"></i>` : `<i class="fa-solid fa-eye-slash"></i>`;
    });
  }

  // Quick PIN Edit
  if (resetPinBtn) {
    resetPinBtn.addEventListener('click', () => {
      const newPin = prompt("Enter your new 4-digit Vending PIN code:", currentUser.pin);
      if (newPin && /^\d{4}$/.test(newPin)) {
        delete REGISTERED_ACCOUNTS[currentUser.pin];
        currentUser.pin = newPin;
        REGISTERED_ACCOUNTS[newPin] = currentUser;
        localStorage.setItem('eniku_user', JSON.stringify(currentUser));
        updateDashboardUI();
        alert("Your 4-digit Vending PIN code has been updated successfully!");
      } else if (newPin !== null) {
        alert("Invalid PIN. Code must be exactly 4 numeric digits.");
      }
    });
  }

  // ==========================================
  // Interactive ESP32 Vending Simulator
  // ==========================================
  function resetLCDToStep1() {
    simState = 1;
    enteredPin = "";
    activeSessionUser = null;

    lcdLine1.textContent = "Welcome Eniku Set";
    lcdLine2.textContent = "enter your code";
    lcdLine3.textContent = "Pass: [ _ _ _ _ ]";
    lcdLine4.textContent = "Press # to Confirm";

    motor1Ind.classList.remove('active');
    motor2Ind.classList.remove('active');
    motor3Ind.classList.remove('active');
    dispensedItem.classList.add('hidden');
  }

  function handleKeypress(key) {
    if (simTimer) clearTimeout(simTimer);

    if (key === '*') {
      // Clear key
      resetLCDToStep1();
      return;
    }

    if (simState === 1) {
      // Step 1: Entering PIN code
      if (key === '#') {
        // Validate PIN
        if (enteredPin.length !== 4) {
          lcdLine3.textContent = "Err: PIN 4 digits!";
          simTimer = setTimeout(resetLCDToStep1, 2000);
          return;
        }

        // Check PIN in registered database
        const account = REGISTERED_ACCOUNTS[enteredPin] || (enteredPin === currentUser.pin ? currentUser : null);

        if (account) {
          if (account.remainingQuota <= 0) {
            lcdLine1.textContent = "Eniku Set Notice";
            lcdLine2.textContent = `Hello ${account.fullName.split(' ')[0]}`;
            lcdLine3.textContent = "Quota Expired: 0 rem";
            lcdLine4.textContent = "Please Renew (150ETB)";
            simTimer = setTimeout(resetLCDToStep1, 4000);
            return;
          }

          activeSessionUser = account;
          simState = 2; // Transition to Step 2

          // Step 2 LCD Display (exact prompt requested by user)
          lcdLine1.textContent = "which type do want";
          lcdLine2.textContent = "1.type 1 Eve";
          lcdLine3.textContent = "2.type 2 Rose";
          lcdLine4.textContent = "3.type 3 Michot";

        } else {
          lcdLine1.textContent = "Invalid PIN Code!";
          lcdLine2.textContent = "Code Not Found";
          lcdLine3.textContent = "Please Try Again";
          lcdLine4.textContent = "or Register Online";
          simTimer = setTimeout(resetLCDToStep1, 3000);
        }

      } else if (/^\d$/.test(key) && enteredPin.length < 4) {
        enteredPin += key;
        const masked = enteredPin.split('').map(() => '*').join(' ').padEnd(7, '_');
        lcdLine3.textContent = `Pass: [ ${masked} ]`;
      }

    } else if (simState === 2) {
      // Step 2: Selecting product type 1, 2, or 3
      if (['1', '2', '3'].includes(key)) {
        let padTypeName = "";
        let padTypeNum = "";

        if (key === '1') {
          padTypeName = "Type 1 Eve";
          padTypeNum = "1";
          motor1Ind.classList.add('active');
        } else if (key === '2') {
          padTypeName = "Type 2 Rose";
          padTypeNum = "2";
          motor2Ind.classList.add('active');
        } else if (key === '3') {
          padTypeName = "Type 3 Michot";
          padTypeNum = "3";
          motor3Ind.classList.add('active');
        }

        simState = 3; // Dispense state

        // Motor Rotation & Dispense Animation
        lcdLine1.textContent = "Dispensing Pad...";
        lcdLine2.textContent = `Motor #${key}: ${padTypeName}`;
        lcdLine3.textContent = "Rotating Spiral...";
        lcdLine4.textContent = "Please Wait...";

        setTimeout(() => {
          // Decrement Quota
          activeSessionUser.remainingQuota = Math.max(0, activeSessionUser.remainingQuota - 1);
          activeSessionUser.usedCount = (activeSessionUser.usedCount || 0) + 1;

          // Add to history
          activeSessionUser.history.unshift({
            title: `Vended ${padTypeName}`,
            detail: `Motor #${key} - Remaining: ${activeSessionUser.remainingQuota} pads`,
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            type: padTypeNum
          });

          if (activeSessionUser.pin === currentUser.pin) {
            currentUser = activeSessionUser;
            localStorage.setItem('eniku_user', JSON.stringify(currentUser));
            updateDashboardUI();
          }

          // Show product in chute
          dispensedItemName.textContent = padTypeName;
          dispensedItem.classList.remove('hidden');

          // Step 3 LCD Display (exact phrasing requested by user)
          // "Eniku Set you use this much and you will still have this much thanks for using"
          lcdLine1.textContent = "Eniku Set";
          lcdLine2.textContent = `Used:${activeSessionUser.usedCount} | Rem:${activeSessionUser.remainingQuota}`;
          lcdLine3.textContent = "you still have this much";
          lcdLine4.textContent = "thanks for using!";

          // Reset simulator after 6 seconds
          simTimer = setTimeout(resetLCDToStep1, 6000);
        }, 2000);
      }
    }
  }

  // Attach Keypad Button Listeners
  keyBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.getAttribute('data-key');
      handleKeypress(key);
    });
  });

  // Keypress keyboard support for easy testing
  document.addEventListener('keydown', (e) => {
    // Only trigger if simulator is in view or focused
    if (document.activeElement.tagName === 'INPUT') return;
    
    if (e.key >= '0' && e.key <= '9') {
      handleKeypress(e.key);
    } else if (e.key === 'Enter') {
      handleKeypress('#');
    } else if (e.key === 'Escape' || e.key === 'Backspace') {
      handleKeypress('*');
    }
  });

});
